<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TableMaster_Ajax {

    public function register() {
        $actions = array(
            'tablemaster_save_table'      => 'save_table',
            'tablemaster_delete_table'    => 'delete_table',
            'tablemaster_duplicate_table' => 'duplicate_table',
            'tablemaster_save_structure'  => 'save_structure',
            'tablemaster_get_structure'   => 'get_structure',
        );

        foreach ( $actions as $hook => $method ) {
            add_action( 'wp_ajax_' . $hook, array( $this, $method ) );
        }
    }

    private function verify_nonce() {
        if ( ! check_ajax_referer( 'tablemaster_admin', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Beveiligingscontrole mislukt.', TMP_TEXT_DOMAIN ) ), 403 );
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Onvoldoende rechten.', TMP_TEXT_DOMAIN ) ), 403 );
        }
    }

    public function save_table() {
        $this->verify_nonce();

        $id       = ! empty( $_POST['id'] )   ? intval( $_POST['id'] )   : 0;
        $name     = ! empty( $_POST['name'] )  ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
        $settings = ! empty( $_POST['settings'] ) ? json_decode( wp_unslash( $_POST['settings'] ), true ) : array();

        if ( ! $name ) {
            wp_send_json_error( array( 'message' => __( 'Naam is verplicht.', TMP_TEXT_DOMAIN ) ) );
        }
        if ( mb_strlen( $name ) > 200 ) {
            wp_send_json_error( array( 'message' => __( 'Naam is te lang (max 200 tekens).', TMP_TEXT_DOMAIN ) ) );
        }
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }

        $settings = self::sanitize_table_settings( $settings );

        $new_id = TableMaster_DB::save_table( array(
            'id'       => $id,
            'name'     => $name,
            'settings' => $settings,
        ) );

        do_action( 'tablemaster_after_save_table', $new_id );
        wp_send_json_success( array( 'id' => $new_id ) );
    }

    private static function sanitize_table_settings( $settings ) {
        $allowed_themes      = array( 'green', 'red', 'blue', 'grey', 'custom' );
        $allowed_search_pos  = array( 'left', 'right', 'top', 'bottom' );
        $allowed_mobile      = array( 'scroll', 'card' );
        $allowed_sort_dir    = array( 'asc', 'desc' );

        $clean = array();
        $clean['caption']            = isset( $settings['caption'] ) ? sanitize_text_field( $settings['caption'] ) : '';
        $clean['search']             = ! empty( $settings['search'] );
        $clean['search_position']    = in_array( $settings['search_position'] ?? '', $allowed_search_pos, true ) ? $settings['search_position'] : 'right';
        $clean['pagination']         = ! empty( $settings['pagination'] );
        $clean['per_page']           = min( 500, max( -1, intval( $settings['per_page'] ?? 10 ) ) );
        $clean['per_page_selector']  = ! empty( $settings['per_page_selector'] );
        $clean['collapsible_groups'] = ! empty( $settings['collapsible_groups'] );
        $clean['mobile_mode']        = in_array( $settings['mobile_mode'] ?? '', $allowed_mobile, true ) ? $settings['mobile_mode'] : 'scroll';
        $clean['default_sort_col']   = sanitize_text_field( $settings['default_sort_col'] ?? '' );
        $clean['default_sort_dir']   = in_array( $settings['default_sort_dir'] ?? '', $allowed_sort_dir, true ) ? $settings['default_sort_dir'] : 'asc';
        $clean['inline_html']        = ! empty( $settings['inline_html'] );
        $clean['column_filters']     = ! empty( $settings['column_filters'] );
        $clean['sticky_first_col']   = ! empty( $settings['sticky_first_col'] );
        $clean['theme']              = in_array( $settings['theme'] ?? '', $allowed_themes, true ) ? $settings['theme'] : 'custom';

        if ( isset( $settings['colors'] ) && is_array( $settings['colors'] ) ) {
            $clean['colors'] = TableMaster_Settings::sanitize_colors( $settings['colors'] );
        }

        return $clean;
    }

    public function delete_table() {
        $this->verify_nonce();
        $id = intval( $_POST['id'] ?? 0 );
        if ( ! $id || ! TableMaster_DB::get_table( $id ) ) {
            wp_send_json_error( array( 'message' => __( 'Tabel niet gevonden.', TMP_TEXT_DOMAIN ) ), 404 );
        }
        TableMaster_DB::delete_table( $id );
        wp_send_json_success();
    }

    public function duplicate_table() {
        $this->verify_nonce();
        $id = intval( $_POST['id'] ?? 0 );
        if ( ! $id || ! TableMaster_DB::get_table( $id ) ) {
            wp_send_json_error( array( 'message' => __( 'Tabel niet gevonden.', TMP_TEXT_DOMAIN ) ), 404 );
        }
        $new_id = TableMaster_DB::duplicate_table( $id );
        if ( ! $new_id ) {
            wp_send_json_error( array( 'message' => __( 'Dupliceren mislukt.', TMP_TEXT_DOMAIN ) ) );
        }
        wp_send_json_success( array( 'id' => $new_id ) );
    }

    public function save_structure() {
        $this->verify_nonce();

        $table_id    = intval( $_POST['table_id'] ?? 0 );
        $columns_raw = wp_unslash( $_POST['columns'] ?? '[]' );
        $rows_raw    = wp_unslash( $_POST['rows']    ?? '[]' );

        if ( strlen( $columns_raw ) > 1048576 || strlen( $rows_raw ) > 10485760 ) {
            wp_send_json_error( array( 'message' => __( 'Data te groot.', TMP_TEXT_DOMAIN ) ), 413 );
        }

        $columns     = json_decode( $columns_raw, true );
        $rows        = json_decode( $rows_raw, true );
        $lang        = sanitize_text_field( wp_unslash( $_POST['lang'] ?? '' ) );

        if ( ! $table_id || ! TableMaster_DB::get_table( $table_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Tabel niet gevonden.', TMP_TEXT_DOMAIN ) ), 404 );
        }
        if ( ! is_array( $columns ) || ! is_array( $rows ) ) {
            wp_send_json_error( array( 'message' => __( 'Ongeldige data.', TMP_TEXT_DOMAIN ) ) );
        }
        if ( count( $columns ) > 100 ) {
            wp_send_json_error( array( 'message' => __( 'Te veel kolommen (max 100).', TMP_TEXT_DOMAIN ) ) );
        }
        if ( count( $rows ) > 10000 ) {
            wp_send_json_error( array( 'message' => __( 'Te veel rijen (max 10.000).', TMP_TEXT_DOMAIN ) ) );
        }

        foreach ( $columns as &$col ) {
            $col['label'] = isset( $col['label'] ) ? mb_substr( sanitize_text_field( $col['label'] ), 0, 200 ) : '';
            $col['type']  = isset( $col['type'] ) ? sanitize_text_field( $col['type'] ) : 'text';
        }
        unset( $col );

        TableMaster_DB::save_table_structure( $table_id, $columns, $rows, $lang );
        do_action( 'tablemaster_after_save_structure', $table_id );
        wp_send_json_success();
    }

    public function get_structure() {
        $this->verify_nonce();
        $table_id = intval( $_POST['table_id'] ?? 0 );
        $lang     = sanitize_text_field( wp_unslash( $_POST['lang'] ?? '' ) );
        $data     = TableMaster_DB::get_table_data( $table_id, $lang );
        wp_send_json_success( $data );
    }
}
