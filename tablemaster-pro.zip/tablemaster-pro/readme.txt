=== TableMaster Pro ===
Contributors: tablemaster
Tags: table, tables, responsive table, sortable table, filterable table, wpml
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.2.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Maak krachtige, interactieve tabellen met groepering, sortering, filtering en paginering.

== Description ==

TableMaster Pro is een complete oplossing voor het aanmaken en beheren van interactieve tabellen in WordPress. 

Functies:
* Onbeperkt tabellen aanmaken
* 3-niveaus groepering (inklapbaar)
* Kleurthema's via kleurpicker (groen, rood, blauw, grijs, custom)
* Zoeken, sorteren en pagineren op de frontend
* Volledig responsief (scroll- of kaartmodus)
* WPML-compatibel
* Shortcode [tablemaster id="X"] en Gutenberg block
* Export naar CSV

== Installation ==

1. Upload de plugin-map naar /wp-content/plugins/
2. Activeer de plugin via het WordPress beheerderspaneel
3. Ga naar TableMaster > Alle Tabellen
4. Gebruik de shortcode [tablemaster id="X"] in uw berichten of pagina's

== Changelog ==

= 1.2.2 =
* Nieuw standaard kleurthema: rood (#D32637) met G1 wit-op-rood, G2 rood-op-roze (#F9E6E7), data op #F8F8F8
* Alle kolommen standaard even breed (table-layout: fixed) — samengevoegde cellen passen zich aan
* Nieuwe tabellen starten nu automatisch met het rode kleurthema
* Alle kleurpresets bijgewerkt naar verfijnde kleuren

= 1.2.1 =
* Nieuw: Klikbaar rijtype-label — klik op Data/G1/G2/G3 om het type direct te wijzigen
* Nieuw: Rij dupliceren knop — kopieer een bestaande rij met alle inhoud
* Nieuw: Slimme auto-merge — lege cellen in groepsrijen worden automatisch samengevoegd op de frontend
* Verbeterd: Placeholder-hints in groepsrij cellen ("Leeg = samenvoegen →")
* Verbeterd: Tooltips op alle rij-knoppen met uitleg
* Verbeterd: Groepsrijen met meerdere gevulde cellen renderen nu als aparte cellen met colspan waar nodig

= 1.2.0 =
* Nieuw: Multi-level kolomheaders (3 niveaus) — maak tabellen met groepskoppen zoals E. coli > Ambulant > 2024-2025
* Per kolom twee optionele velden: "Header groep 1" en "Header groep 2" voor automatische colspan/rowspan berekening
* Rood kleurthema verfijnd: exacte kleuren afgestemd op branding (zachtere randen, neutrale even-rijen)
* Standaard border-radius verhoogd naar 12px
* Verticale celranden verwijderd voor een schoner uiterlijk

= 1.1.2 =
* Fix: WPML strings worden nu automatisch geregistreerd bij plugin-update (geen handmatig opslaan meer nodig)
* Fix: "Vertalen" knop linkt nu correct naar de WPML String Translation pagina met juiste context-filter
* Tabelnaam wordt nu ook als vertaalbare string geregistreerd

= 1.1.1 =
* Fix: Elementor-compatibiliteit — kleuren en stijlen worden nu correct geladen in Elementor editor en frontend
* Fix: Shortcode-detectie werkt nu ook als de shortcode in Elementor widgets staat

= 1.1.0 =
* Kleuren worden nu direct toegepast op de admin rijtabel (aparte preview verwijderd)
* Nieuwe globale instelling: Tabel border-radius (px) — geldt voor alle tabellen
* WPML-integratie verbeterd: wpml-config.xml, betere string-context per tabel
* "Vertalen" knop in tabellenlijst en bewerkpagina (linkt naar WPML String Translation)
* Derde demotabel "Anatomopathologie (Kiemen)" toegevoegd
* CSS-fix: groepsrijen gebruiken nu inner wrapper div voor correcte layout

= 1.0.0 =
* Initiële release
